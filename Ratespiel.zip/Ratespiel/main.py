from random import randint
Zufallszahl = randint(1,100)
print("Ratespiel: errate die Zahle zwischen 1 und 100")

while True:


    eingabezahl = int(input("Zahl eingabe: "))


    if eingabezahl < 1 : print("bitte eine zahl zwischen 1 und 100 eingeben")
    if eingabezahl >100: print("bitte eine zahl zwischen 1 und 100 eingeben")

    if eingabezahl < Zufallszahl: print("zu klein")
    if eingabezahl > Zufallszahl: print("zu gross")

    if eingabezahl == Zufallszahl:

        print("Korrekt Die zahl war %d." % Zufallszahl)
        break

